// Class: A2DynamicMem
// Implements Degragment in A2. No other changes should be needed for other functions.

public class A2DynamicMem extends A1DynamicMem {
      
    public A2DynamicMem() {  super(); }

    public A2DynamicMem(int size) { super(size); }

    public A2DynamicMem(int size, int dict_type) { super(size, dict_type); }

    // In A2, you need to test your implementation using BSTrees and AVLTrees. 
    // No changes should be required in the A1DynamicMem functions. 
    // They should work seamlessly with the newly supplied implementation of BSTrees and AVLTrees
    // For A2, implement the Defragment function for the class A2DynamicMem and test using BSTrees and AVLTrees. 

    public void Defragment() {
        //We create a new Tree which hold the elements of the freeBlk but keyed by address
        Dictionary freeBlkByAddress;
        Dictionary currentNode;

        if(type==2){
            freeBlkByAddress = new BSTree();
            currentNode = (BSTree) this.freeBlk.getFirst();
        }else if (type==3){
            freeBlkByAddress = new AVLTree();
            currentNode = (AVLTree) this.freeBlk.getFirst();
        }else{
            return;
        }

        if(currentNode==null){
            return;
        }
        while(currentNode != null){
            //Insert every node of freeBlk into freeBlkByAddress
            freeBlkByAddress.Insert(currentNode.address, currentNode.size, currentNode.address);
            currentNode = currentNode.getNext();
        }
        currentNode = freeBlkByAddress.getFirst();
        //traverse freeBlkByAddress and find every possible contiguous free blocks
        Dictionary nextNode;

        if(type==2){
            nextNode = currentNode.getNext();
        }else if (type==3){
            nextNode = currentNode.getNext();
        }else{
            return;
        }

        while(nextNode!=null){
            if(currentNode.key+currentNode.size==nextNode.key){
                //if contiguous, we merge them
                Dictionary nodeTBD1;
                Dictionary nodeTBD2;
                if(type==2){
                    nodeTBD1 = new BSTree(currentNode.address, currentNode.size, currentNode.size);
                    nodeTBD2 = new BSTree(nextNode.address, nextNode.size, nextNode.size);
                }else if(type==3){
                    nodeTBD1 = new AVLTree(currentNode.address, currentNode.size, currentNode.size);
                    nodeTBD2 = new AVLTree(nextNode.address, nextNode.size, nextNode.size);
                }else{
                    return;
                }
                //original free blocks are deleted from the freeBlk dictionary
                this.freeBlk.Delete(nodeTBD1);
                this.freeBlk.Delete(nodeTBD2);
                Dictionary newNodeFreeBySize;
                if(type==2){
                    newNodeFreeBySize = (BSTree) this.freeBlk.Insert(currentNode.address, currentNode.size+nextNode.size, currentNode.size+nextNode.size);
                }else if(type==3){
                    newNodeFreeBySize = (AVLTree) this.freeBlk.Insert(currentNode.address, currentNode.size+nextNode.size, currentNode.size+nextNode.size);
                }else{
                    return;
                }
                //new Free Node is added to the freeBlk and freeBlkByAddress by using the corresponding keys
                freeBlkByAddress.Delete(currentNode);
                freeBlkByAddress.Delete(nextNode);
                Dictionary newNodeFreeByAddress;
                if(type==2){
                    newNodeFreeByAddress = (BSTree) freeBlkByAddress.Insert(newNodeFreeBySize.address,newNodeFreeBySize.size, newNodeFreeBySize.address);
                }else if(type==3){
                    newNodeFreeByAddress = (AVLTree) freeBlkByAddress.Insert(newNodeFreeBySize.address,newNodeFreeBySize.size, newNodeFreeBySize.address);
                }else{
                    return;
                }
                currentNode = newNodeFreeByAddress;
                nextNode = newNodeFreeByAddress.getNext();
            }else{
                currentNode = currentNode.getNext();
                nextNode = nextNode.getNext();
            }
        }
        //defragmentation complete, we delete the freeBlkByAddress dictionary
        freeBlkByAddress = null;
        return;
    }
}